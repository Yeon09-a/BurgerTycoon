package com.cookandroid.burgertycoon;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {

    Chronometer timer; // 타이머
    Button endBtn, throwBtn, outBtn; // 영업종료, 버리기, 음식 내보내기
    TextView orderText, moneyText, dayText, guestText; // 주문, 수익, 몇일차, 손님 수
    ImageView[] ingredients = new ImageView[8]; // 재료 쌓을 이미지뷰
    ImageView[] ingreBtns = new ImageView[8]; // 재료 버튼 이미지뷰
    TextView[] ingreTexts = new TextView[8]; // 재료 개수 텍스트
    Integer[] ingreID = {R.id.ingre00, R.id.ingre01, R.id.ingre02, R.id.ingre03, R.id.ingre04, R.id.ingre05, R.id.ingre06, R.id.ingre07};
    Integer[] ingreBtnID = {R.id.breadBBtn, R.id.saladBtn, R.id.onionBtn, R.id.meatBtn, R.id.tomatoesBtn, R.id.cheeseBtn, R.id.picklesBtn, R.id.breadTBtn};
    Integer[] ingreCountID = {R.id.breadBText, R.id.saladText, R.id.onionText, R.id.meatText, R.id.tomatoesText, R.id.cheeseText, R.id.picklesText, R.id.breadTText};

    Integer[] ingreImages = {R.drawable.breadbottom, R.drawable.salad, R.drawable.onion, R.drawable.meat, R.drawable.tomatoes, R.drawable.cheese, R.drawable.pickles, R.drawable.breadtop};
    String[] ingreName = {"아랫빵  ", "양상추  ", "양파  ", "패티  ", "토마토  ", "치즈  ", "피클  ", "윗빵  ", ""}; // 주문에 적을 문자열

    int money, day, goalGuests, time; // 수익, 몇일차, 목표 손님 수, 분
    Integer[] ingreCount = new Integer[8]; // 현재 가지고 있는 재료 개수
    float rating; // 별점
    int ingreNum = 0; // 쌓은 재료 개수
    int guests = 0; // 받은 손님 수

    Integer[] order = new Integer[8]; // 주문 재료 배열
    Integer[] burger = {8, 8, 8, 8, 8, 8, 8, 8}; // 내가 만든 버거 재료 배열

    View gameResultDialog; // 게임 결과 대화상자 뷰
    TextView resultText, dlgGuestText, dlgMoneyText;
    boolean isSuccessful = false; // 게임 클리어 유무무
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gamescene);

        timer = (Chronometer) findViewById(R.id.timer);
        endBtn = (Button)findViewById(R.id.endBtn);
        throwBtn = (Button)findViewById(R.id.throwBtn);
        outBtn = (Button)findViewById(R.id.outBtn);

        orderText = (TextView) findViewById(R.id.orderText);
        moneyText = (TextView) findViewById(R.id.moneyText);
        dayText = (TextView) findViewById(R.id.dayText);
        guestText = (TextView) findViewById(R.id.guestText);

        Intent gameIntent = getIntent();
        rating = gameIntent.getFloatExtra("Rating", 0);
        day = gameIntent.getIntExtra("Day", 0);
        goalGuests = gameIntent.getIntExtra("GoalGuests", 0);
        time = gameIntent.getIntExtra("Time", 0);
        ingreCount[0] = gameIntent.getIntExtra("BreadBottom", 0);
        ingreCount[1] = gameIntent.getIntExtra("Salad", 0);
        ingreCount[2] = gameIntent.getIntExtra("Onion", 0);
        ingreCount[3] = gameIntent.getIntExtra("Meat", 0);
        ingreCount[4] = gameIntent.getIntExtra("Tomatoes", 0);
        ingreCount[5] = gameIntent.getIntExtra("Cheese", 0);
        ingreCount[6] = gameIntent.getIntExtra("Pickles", 0);
        ingreCount[7] = gameIntent.getIntExtra("BreadTop", 0);

        dayText.setText(day + "일차");

        for(int i = 0; i < ingredients.length; i++){
            ingredients[i] = (ImageView)findViewById(ingreID[i]);
            ingreBtns[i] = (ImageView) findViewById(ingreBtnID[i]);
            ingreTexts[i] = (TextView) findViewById(ingreCountID[i]);
            ingreTexts[i].setText(ingreCount[i].toString());
        }

        for(int j = 0; j < ingredients.length; j++) {
            final int index;
            index = j;
            ingreBtns[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(ingreNum < 8){ // 쌓은 재료가 8개 이하인 경우
                        Integer count = Integer.parseInt(ingreTexts[index].getText().toString()); // 해당 재료의 현재 개수 가져오기

                        if(count > 0){ // 재료가 있는 경우
                            ingredients[ingreNum].setImageResource(ingreImages[index]);
                            burger[ingreNum] = index;
                            count -= 1;
                            ingreTexts[index].setText(count.toString());
                            ingreCount[index] = count;
                            ingreNum +=1;

                        }
                        else{ // 재료가 없는 경우
                            Toast.makeText(getApplicationContext(), "재료가 부족합니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else { // 8겹 다 쌓은 경우
                        Toast.makeText(getApplicationContext(), "재료를 더이상 추가할 수 없습니다.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        throwBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetBurger();
            }
        });

        outBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for(int i = 0; i < 8; i++){
                    if(order[i] != burger[i]){ // 주문의 재료와 내가 만든 버거의 재료가 다른 경우
                        Toast.makeText(getApplicationContext(), "주문과 다른 햄버거입니다.\n가게 평점이 감소됩니다.", Toast.LENGTH_SHORT).show();
                        money -= 100;
                        rating -= 0.3;
                        guests -= 1;
                        break;
                    }
                }
                money += 100;
                rating += 0.1;
                guests += 1;

                if(rating >= 5.0f){
                    rating = 5.0f;
                }

                moneyText.setText(money + "원");
                guestText.setText(guests + "명");

                resetBurger();
                setOrder(day);
            }
        });

        endBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer.stop();
                long restTime = timer.getBase() - SystemClock.elapsedRealtime();
                AlertDialog.Builder dlg = new AlertDialog.Builder(GameActivity.this);
                dlg.setMessage("영업을 종료하시겠습니까?");
                dlg.setCancelable(false);
                dlg.setPositiveButton("종료", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        showResultDialog();
                    }
                });
                dlg.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        timer.setBase(SystemClock.elapsedRealtime() + restTime);
                        timer.start();
                    }
                });
                dlg.show();
            }
        });

        setOrder(day);

        timer.setBase(SystemClock.elapsedRealtime() + 60000 * time);
        timer.start();

        timer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if(timer.getBase() - SystemClock.elapsedRealtime() <= 0){
                    timer.stop();

                    showResultDialog();
                }
            }
        });

    }

    private void setOrder(int day){
        order[0] = 0;
        if(day <= 3){
            for(int i = 1; i < 8; i++){
                int rNum = (int)(Math.random() * 6 + 1);
                if(i < 4){
                    order[i] = rNum;
                }
                else if (i == 4)
                {
                    order[i] = 7;
                }
                else{
                    order[i] = 8;
                }
            }
        }
        else{
            for(int i = 1; i < 8; i++){
                int rNum = (int)(Math.random() * 6 + 1);
                if(i < 7){
                    order[i] = rNum;
                }
                else if (i == 7)
                {
                    order[i] = 7;
                }
            }
        }

        String orderStr = "";

        for(int j = 0; j < 8; j++){
            orderStr += ingreName[order[j]];
            if(j == 4) {
                orderStr += "\n";
            }
        }

        orderText.setText(orderStr);
    }

    private void resetBurger(){
        ingreNum = 0;
        for(int i =0; i < 8; i++) {
            ingredients[i].setImageResource(0);
            burger[i] = 8;
        }
    }

    private void showResultDialog(){
        gameResultDialog = (View) View.inflate(GameActivity.this, R.layout.gameresult, null);
        resultText = (TextView) gameResultDialog.findViewById(R.id.resultText);
        dlgGuestText = (TextView) gameResultDialog.findViewById(R.id.dlgGuestText);
        dlgMoneyText = (TextView) gameResultDialog.findViewById(R.id.dlgMoneyText);

        dlgGuestText.setText(guests + "명");
        dlgMoneyText.setText(money + "원");

        if(guests < goalGuests) {
            resultText.setText("영업 실패");
            isSuccessful = false;
        }
        else{
            resultText.setText("영업 성공!");
            isSuccessful = true;
        }

        AlertDialog.Builder endDlg = new AlertDialog.Builder(GameActivity.this);
        endDlg.setView(gameResultDialog);
        endDlg.setTitle("영업 결과");
        endDlg.setCancelable(false);

        endDlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(isSuccessful){
                    Intent lobbyIntent = new Intent(getApplicationContext(), LobbyActivity.class);
                    lobbyIntent.putExtra("Money", money);
                    lobbyIntent.putExtra("Rating", rating);
                    lobbyIntent.putExtra("BreadTop", ingreCount[7]);
                    lobbyIntent.putExtra("BreadBottom", ingreCount[0]);
                    lobbyIntent.putExtra("Salad", ingreCount[1]);
                    lobbyIntent.putExtra("Pickles", ingreCount[6]);
                    lobbyIntent.putExtra("Meat", ingreCount[3]);
                    lobbyIntent.putExtra("Cheese", ingreCount[5]);
                    lobbyIntent.putExtra("Tomatoes", ingreCount[4]);
                    lobbyIntent.putExtra("Onion", ingreCount[2]);
                    setResult(RESULT_OK, lobbyIntent);
                    finish();
                }
                else{
                    Intent lobbyIntent = new Intent(getApplicationContext(), LobbyActivity.class);
                    lobbyIntent.putExtra("Money", money);
                    lobbyIntent.putExtra("Rating", rating);
                    lobbyIntent.putExtra("BreadTop", ingreCount[7]);
                    lobbyIntent.putExtra("BreadBottom", ingreCount[0]);
                    lobbyIntent.putExtra("Salad", ingreCount[1]);
                    lobbyIntent.putExtra("Pickles", ingreCount[6]);
                    lobbyIntent.putExtra("Meat", ingreCount[3]);
                    lobbyIntent.putExtra("Cheese", ingreCount[5]);
                    lobbyIntent.putExtra("Tomatoes", ingreCount[4]);
                    lobbyIntent.putExtra("Onion", ingreCount[2]);
                    setResult(RESULT_CANCELED, lobbyIntent);
                    finish();
                }
            }
        });
        endDlg.show();
    }
}
