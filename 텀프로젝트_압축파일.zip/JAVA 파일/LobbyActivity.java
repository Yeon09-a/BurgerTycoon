package com.cookandroid.burgertycoon;

import static androidx.activity.result.contract.ActivityResultContracts.*;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LobbyActivity extends AppCompatActivity {

    SharedPreferences pref;
    SharedPreferences.Editor editor;

    String plyName, rtrName;
    int day, money, goalGuest;
    float rating;
    TextView signText, signNameText, dayText, moneyText, infoDayText;
    RatingBar ratingBar;
    Button gameBtn, stockBtn, backBtn;
    View goalDialog;

    // 재료 개수
    int breadTop;
    int breadBottom;
    int salad;
    int pickles;
    int meat;
    int cheese;
    int tomatoes;
    int onion;

    // 게임 레벨 관련
    TextView dlgDayText, dlgGoalGuestText, dlgSizeText, dlgTimeText;
    int time;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lobby);

        pref = getSharedPreferences("pref",Activity.MODE_PRIVATE);
        editor = pref.edit();

        signText = (TextView) findViewById(R.id.signText);
        signNameText = (TextView) findViewById(R.id.signNameText);
        dayText = (TextView) findViewById(R.id.dayText);
        moneyText = (TextView) findViewById(R.id.moneyText);
        infoDayText = (TextView) findViewById(R.id.infoDayText);

        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        gameBtn = (Button) findViewById(R.id.gameBtn);
        stockBtn = (Button) findViewById(R.id.stockBtn);
        backBtn = (Button) findViewById(R.id.backBtn);

        if(pref.contains("Day")){
            day = pref.getInt("Day", 0);
            money = pref.getInt("Money", 0);
            rating = pref.getFloat("Rating", 0);
            breadTop = pref.getInt("BreadTop", 0);
            breadBottom = pref.getInt("BreadBottom", 0);
            salad = pref.getInt("Salad", 0);
            pickles = pref.getInt("Pickles", 0);
            meat = pref.getInt("Meat", 0);
            cheese = pref.getInt("Cheese", 0);
            tomatoes = pref.getInt("Tomatoes", 0);
            onion = pref.getInt("Onion", 0);

            plyName = pref.getString("PlyName", null);
            rtrName =pref.getString("RtrName", null);
        }
        else{
            day = 1;
            money = 200;
            rating = 5;
            breadTop = 10;
            breadBottom = 10;
            salad = 10;
            pickles = 10;
            meat = 10;
            cheese = 10;
            tomatoes = 10;
            onion = 10;

            Intent fromIntent = getIntent();
            plyName = fromIntent.getStringExtra("PlyName");
            rtrName = fromIntent.getStringExtra("ResName");
        }

        signText.setText(rtrName);
        signNameText.setText(plyName);

        dayText.setText(day + "일차");
        infoDayText.setText(day + "일차");
        moneyText.setText(money + "원");
        ratingBar.setRating(rating);

        gameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 게임 난이도 대화상자 발생
                goalDialog = (View) View.inflate(LobbyActivity.this, R.layout.goaldialog, null);
                dlgDayText = (TextView) goalDialog.findViewById(R.id.dlgDayText);
                dlgGoalGuestText = (TextView) goalDialog.findViewById(R.id.dlgGoalGuestText);
                dlgSizeText = (TextView) goalDialog.findViewById(R.id.dlgSizeText);
                dlgTimeText = (TextView) goalDialog.findViewById(R.id.dlgTimeText);

                if(day <= 3){
                    goalGuest = 8;
                    time = 2;
                    dlgDayText.setText(day + "일차");
                    dlgGoalGuestText.setText(goalGuest + "명");
                    dlgSizeText.setText("5겹");
                    dlgTimeText.setText(time + "분");
                }
                else{
                    goalGuest = 12;
                    time = 2;
                    dlgDayText.setText(day + "일차");
                    dlgGoalGuestText.setText(goalGuest + "명");
                    dlgSizeText.setText("8겹");
                    dlgTimeText.setText(time + "분");
                }

                AlertDialog.Builder dlg = new AlertDialog.Builder(LobbyActivity.this);
                dlg.setView(goalDialog);
                dlg.setCancelable(false);
                dlg.setPositiveButton("영업시작", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 양방향 intent 게임 씬으로 이동
                        Intent gameIntent = new Intent(getApplicationContext(), GameActivity.class);
                        gameIntent.putExtra("Day", day);
                        gameIntent.putExtra("Rating", rating);
                        gameIntent.putExtra("GoalGuests", goalGuest);
                        gameIntent.putExtra("Time", time);
                        gameIntent.putExtra("BreadTop", breadTop);
                        gameIntent.putExtra("BreadBottom", breadBottom);
                        gameIntent.putExtra("Salad", salad);
                        gameIntent.putExtra("Pickles", pickles);
                        gameIntent.putExtra("Meat", meat);
                        gameIntent.putExtra("Cheese", cheese);
                        gameIntent.putExtra("Tomatoes", tomatoes);
                        gameIntent.putExtra("Onion", onion);

                        startActivityForResult(gameIntent, 0);
                    }
                });
                dlg.setNegativeButton("취소", null);
                dlg.show();
            }
        });

        stockBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 재고 창으로 이동. 양방향 intent
                Intent stockIntent = new Intent(getApplicationContext(), StockActivity.class);
                stockIntent.putExtra("CountBreadTop", breadTop);
                stockIntent.putExtra("CountBreadBottom", breadBottom);
                stockIntent.putExtra("CountSalad", salad);
                stockIntent.putExtra("CountPickles", pickles);
                stockIntent.putExtra("CountMeat", meat);
                stockIntent.putExtra("CountCheese", cheese);
                stockIntent.putExtra("CountTomatoes", tomatoes);
                stockIntent.putExtra("CountOnion", onion);
                stockIntent.putExtra("StockDay", day);
                stockIntent.putExtra("StockMoney", money);
                stockIntent.putExtra("StockPlyName", plyName);
                stockIntent.putExtra("StockRtrName", rtrName);

                startActivityForResult(stockIntent, 1);

            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveValueData();
                Intent outIntent =  new Intent(getApplicationContext(), MainActivity.class);
                outIntent.putExtra("IsBack", true);
                startActivity(outIntent);
                finish();// 해당 액티비티를 종료 -> 해당 액티비티로 이동하기 전 액티비티로 감.
            }
        });

        saveValueData();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 0){
            if (resultCode == RESULT_OK) {
                money = money + data.getIntExtra("Money", 0);
                rating = data.getFloatExtra("Rating", 0);
                breadBottom = data.getIntExtra("BreadBottom", 0);
                breadTop = data.getIntExtra("BreadTop", 0);
                salad = data.getIntExtra("Salad", 0);
                pickles = data.getIntExtra("Pickles", 0);
                meat = data.getIntExtra("Meat", 0);
                cheese = data.getIntExtra("Cheese", 0);
                tomatoes = data.getIntExtra("Tomatoes", 0);
                onion = data.getIntExtra("Onion", 0);
                setValues();

                if(day == 8){
                    ending();
                }
            }
            else if(resultCode == RESULT_CANCELED){
                money = money + data.getIntExtra("Money", 0);
                rating = data.getFloatExtra("Rating", 0);
                breadBottom = data.getIntExtra("BreadBottom", 0);
                breadTop = data.getIntExtra("BreadTop", 0);
                salad = data.getIntExtra("Salad", 0);
                pickles = data.getIntExtra("Pickles", 0);
                meat = data.getIntExtra("Meat", 0);
                cheese = data.getIntExtra("Cheese", 0);
                tomatoes = data.getIntExtra("Tomatoes", 0);
                onion = data.getIntExtra("Onion", 0);

                moneyText.setText(money+"원");
                ratingBar.setRating(rating);
            }
        }
        else if(requestCode == 1){
            if (resultCode == RESULT_OK){
                money = data.getIntExtra("StockMoney", 0);
                breadBottom = data.getIntExtra("CountBreadBottom", 0);
                breadTop = data.getIntExtra("CountBreadTop", 0);
                salad = data.getIntExtra("CountSalad", 0);
                pickles = data.getIntExtra("CountPickles", 0);
                meat = data.getIntExtra("CountMeat", 0);
                cheese = data.getIntExtra("CountCheese", 0);
                tomatoes = data.getIntExtra("CountTomatoes", 0);
                onion = data.getIntExtra("CountOnion", 0);
                moneyText.setText(money+"원");
            }
        }

        saveValueData();
    }

    private void setValues(){
        day += 1;
        dayText.setText(day+"일차");
        infoDayText.setText(day+"일차");
        moneyText.setText(money+"원");
        ratingBar.setRating(rating);
    }

    private void ending(){
        Intent conIntent = new Intent(getApplicationContext(), StoryConversationActivity.class);
        conIntent.putExtra("DialogNum", 4);
        conIntent.putExtra("Money", money);
        conIntent.putExtra("Rating", rating);
        startActivity(conIntent);
        finish();
    }

    private void saveValueData(){
        editor.putInt("Day", day);
        editor.putInt("Money", money);
        editor.putString("PlyName", plyName);
        editor.putString("RtrName", rtrName);
        editor.putFloat("Rating", rating);
        editor.putInt("BreadTop", breadTop);
        editor.putInt("BreadBottom", breadBottom);
        editor.putInt("Salad", salad);
        editor.putInt("Pickles", pickles);
        editor.putInt("Meat", meat);
        editor.putInt("Cheese", cheese);
        editor.putInt("Tomatoes", tomatoes);
        editor.putInt("Onion", onion);
        editor.commit();
    }
}
