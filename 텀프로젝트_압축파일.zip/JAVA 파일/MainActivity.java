package com.cookandroid.burgertycoon;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SharedPreferences pref;
    SharedPreferences.Editor editor;

    Button startBtn, exitBtn, continueBtn;
    EditText plyNameEdt, rtrNameEdt;
    View mainDialog;
    String playerName, rtrName;

    boolean isBack= false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pref = getSharedPreferences("pref",Activity.MODE_PRIVATE);
        editor = pref.edit();

        startBtn = (Button) findViewById(R.id.startBtn);
        exitBtn = (Button) findViewById(R.id.exitBtn);
        continueBtn = (Button) findViewById(R.id.continueBtn);

        Intent lobbyIntent = getIntent();
        isBack = lobbyIntent.getBooleanExtra("IsBack", false);

        if(pref.contains("Day") || isBack){
            startBtn.setText("새로하기");
            continueBtn.setVisibility(View.VISIBLE);
            isBack = false;
        }
        else{
            startBtn.setText("게임시작");
            continueBtn.setVisibility(View.GONE);
        }

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainDialog = (View) View.inflate(MainActivity.this, R.layout.maindialog, null);

                AlertDialog.Builder dlg = new AlertDialog.Builder(MainActivity.this);
                dlg.setTitle("플레이어 정보 입력");
                dlg.setView(mainDialog);
                dlg.setCancelable(false);
                dlg.setPositiveButton("확인", null);
                dlg.setNegativeButton("취소", null);

                AlertDialog checkDlg = dlg.create();
                checkDlg.show();
                checkDlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        plyNameEdt = (EditText) mainDialog.findViewById(R.id.plyNameEdit);
                        rtrNameEdt = (EditText) mainDialog.findViewById(R.id.rtrNameEdit);
                        playerName = plyNameEdt.getText().toString();
                        rtrName = rtrNameEdt.getText().toString();

                        if(playerName.length() > 5 || playerName.equals("")){
                            AlertDialog.Builder plyDlg = new AlertDialog.Builder(MainActivity.this);
                            plyDlg.setMessage("이름은 1~5글자이어야 합니다.");
                            plyDlg.setPositiveButton("확인", null);
                            plyDlg.setCancelable(false);
                            plyDlg.show();
                        }
                        else if(rtrName.length() > 5 || rtrName.equals("")){
                            AlertDialog.Builder plyDlg = new AlertDialog.Builder(MainActivity.this);
                            plyDlg.setMessage("가게 명은 1~5글자이어야 합니다.");
                            plyDlg.setPositiveButton("확인", null);
                            plyDlg.setCancelable(false);
                            plyDlg.show();
                        }
                        else{
                            if(pref.contains("Day")){
                                editor.clear();
                                editor.commit();
                            }

                            // 다음 액티비티로 이동
                            Intent conIntent = new Intent(getApplicationContext(), StoryConversationActivity.class);
                            conIntent.putExtra("DialogNum", 0);
                            conIntent.putExtra("PlyName", playerName);
                            conIntent.putExtra("ResName", rtrName);

                            startActivity(conIntent);
                            checkDlg.dismiss();
                            finish();
                        }
                    }
                });
            }
        });

        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lobbyIntent = new Intent(getApplicationContext(), LobbyActivity.class);
                startActivity(lobbyIntent);
                finish();
            }
        });

        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }


}