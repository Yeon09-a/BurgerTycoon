package com.cookandroid.burgertycoon;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class StoryConversationActivity extends AppCompatActivity {

    SharedPreferences pref;
    SharedPreferences.Editor editor;

    int dialogNum;
    String plyName, rtrName;
    TextView cvsText;
    String cvsStr = "";
    String[] dayDialog;

    int money;
    float rating;
    String ratingStr;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storyconversation);

        pref = getSharedPreferences("pref",Activity.MODE_PRIVATE);
        editor = pref.edit();

        cvsText = (TextView) findViewById(R.id.cvsText);

        Intent conIntent = getIntent();
        dialogNum = conIntent.getIntExtra("DialogNum", 0);
        if(dialogNum == 0){
            plyName = conIntent.getStringExtra("PlyName");
            rtrName = conIntent.getStringExtra("ResName");
        }
        else {
            money = conIntent.getIntExtra("Money", 0);
            rating = conIntent.getFloatExtra("Rating", 0);
            ratingStr = String.format("%.1f", rating);
        }

        dayDialog = new String[] { // 대화 추가
                "내 이름은 " + plyName + "\n",
                "드디어 나의 오랜 꿈인 " + rtrName + " 버거를 개업했다.\n",
                "일주일 동안 열심히 햄버거를 만들어서\n최고의 햄버거 사장님이 되겠어!",
                "-1",
                "드디어 일주일이 지났다.\n",
                "일주일 동안 수익 " + money + "원,\n별점 5점 만점의 " + ratingStr + "점을 받았어!\n",
                "이 일주일 간의 경험을 통해\n앞으로 더 열심히 하자!\n",
                ".\n",
                ".\n",
                ".\n",
                ".\n",
                "Ending!",
                "-2"
        };

        cvsStr += dayDialog[dialogNum];
        cvsText.setText(cvsStr);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_UP) {
            dialogNum += 1;
            if(dayDialog[dialogNum].equals("-1")){
                Intent intent = new Intent(getApplicationContext(), LobbyActivity.class);
                intent.putExtra("PlyName", plyName);
                intent.putExtra("ResName", rtrName);
                startActivity(intent);
                finish();
            }
            else if(dayDialog[dialogNum].equals("-2")){
                editor.clear();
                editor.commit();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
            else {

                cvsStr += dayDialog[dialogNum];
                cvsText.setText(cvsStr);
            }
        }
        return true;
    }
}
