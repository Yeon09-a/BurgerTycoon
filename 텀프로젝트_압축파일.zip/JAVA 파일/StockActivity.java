package com.cookandroid.burgertycoon;

import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

import androidx.annotation.Nullable;

@SuppressWarnings("deprecation")
public class StockActivity extends TabActivity {

    String plyName, rtrName;
    int day, money;
    TextView stockSignText, stockSignNameText, stockDayText, stockMoneyText;
    TextView[] ingreCountText = new TextView[8];
    Integer[] ingreCountID = {R.id.breadTCountText, R.id.breadBCountText, R.id.saladCountText, R.id.onionCountText, R.id.meatCountText, R.id.tomatoesCountText, R.id.cheeseCountText, R.id.picklesCountText};
    TextView[] ingrePriceText = new TextView[8];
    Integer[] ingrePriceID = {R.id.breadTPriceText, R.id.breadBPriceText, R.id.saladPriceText, R.id.onionPriceText, R.id.meatPriceText, R.id.tomatoesPriceText, R.id.cheesePriceText, R.id.picklesPriceText};

    FrameLayout[] ingreFrame = new FrameLayout[8];
    Integer[] ingreFrameID = {R.id.breadTFrame, R.id.breadBFrame, R.id.saladFrame, R.id.onionFrame, R.id.meatFrame, R.id.tomatoesFrame, R.id.cheeseFrame, R.id.picklesFrame};

    Button stockBackBtn;

    View stockDialog;
    TextView dlgIngreNameText, dlgIngrePriceText, dlgIngreCountText, dlgAllPriceText;
    EditText dlgIngreCountEdit;

    Integer[] prices = {8, 8, 10, 10, 13, 10, 13, 8};
    Integer[] counts = new Integer[8];
    String[] ingreName = {"윗빵", "아랫빵", "양상추", "양파", "패티", "토마토", "치즈", "피클"};

    int allPrice, ingreCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stockscene);

        TabHost tabHost = getTabHost();

        TabSpec stockTapSpec = tabHost.newTabSpec("STOCK").setIndicator("재고");
        stockTapSpec.setContent(R.id.stockLayer);
        tabHost.addTab(stockTapSpec);

        TabSpec purchaseTapSpec = tabHost.newTabSpec("PURCHASE").setIndicator("구입");
        purchaseTapSpec.setContent(R.id.purchaseLayer);
        tabHost.addTab(purchaseTapSpec);

        tabHost.setCurrentTab(0);

        stockSignText = (TextView) findViewById(R.id.stockSignText);
        stockSignNameText = (TextView) findViewById(R.id.stockSignNameText);
        stockDayText = (TextView) findViewById(R.id.stockDayText);
        stockMoneyText = (TextView) findViewById(R.id.stockMoneyText);

        stockBackBtn = (Button) findViewById(R.id.stockBackBtn);

        Intent stockIntent = getIntent();
        plyName = stockIntent.getStringExtra("StockPlyName");
        rtrName = stockIntent.getStringExtra("StockRtrName");
        day = stockIntent.getIntExtra("StockDay", 0);
        money = stockIntent.getIntExtra("StockMoney", 0);
        counts[0] = stockIntent.getIntExtra("CountBreadTop", 0);
        counts[1] = stockIntent.getIntExtra("CountBreadBottom", 0);
        counts[2] = stockIntent.getIntExtra("CountSalad", 0);
        counts[3] = stockIntent.getIntExtra("CountOnion", 0);
        counts[4] = stockIntent.getIntExtra("CountMeat", 0);
        counts[5] = stockIntent.getIntExtra("CountTomatoes", 0);
        counts[6] = stockIntent.getIntExtra("CountCheese", 0);
        counts[7] = stockIntent.getIntExtra("CountPickles", 0);

        stockSignText.setText(rtrName);
        stockSignNameText.setText(plyName);
        stockDayText.setText(day + "일차");
        stockMoneyText.setText(money + "원");

        for(int i = 0; i < 8; i++){
            ingreCountText[i] = (TextView) findViewById(ingreCountID[i]);
            ingrePriceText[i] = (TextView) findViewById(ingrePriceID[i]);
            ingreFrame[i] = (FrameLayout) findViewById(ingreFrameID[i]);

            ingreCountText[i].setText(counts[i].toString());
            ingrePriceText[i].setText(prices[i] + "원");
        }

        for(int j = 0; j < 8; j++){
            final int index;
            index = j;
            ingreFrame[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    stockDialog = (View) View.inflate(StockActivity.this, R.layout.stockdialog, null);
                    dlgIngreNameText = (TextView) stockDialog.findViewById(R.id.dlgIngreNameText);
                    dlgIngrePriceText = (TextView) stockDialog.findViewById(R.id.dlgIngrePricePrice);
                    dlgIngreCountText = (TextView) stockDialog.findViewById(R.id.dlgIngreCountText);
                    dlgAllPriceText = (TextView) stockDialog.findViewById(R.id.dlgAllPriceText);

                    int price = prices[index];

                    dlgIngreCountEdit = (EditText) stockDialog.findViewById(R.id.dlgIngreCountEdit);

                    dlgIngreNameText.setText(ingreName[index]);
                    dlgIngrePriceText.setText(price + "원");
                    dlgIngreCountText.setText(counts[index] + "개");

                    dlgIngreCountEdit.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        }

                        @Override
                        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                            String num = charSequence.toString();
                            if(!num.equals("")){
                                ingreCount = Integer.parseInt(charSequence.toString());
                                allPrice = ingreCount * price;
                                dlgAllPriceText.setText(allPrice + "원");
                            }
                            else{
                                dlgAllPriceText.setText("0원");
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable editable) {
                        }
                    });

                    AlertDialog.Builder dlg = new AlertDialog.Builder(StockActivity.this);
                    dlg.setTitle("재료 구매");
                    dlg.setView(stockDialog);
                    dlg.setCancelable(false);
                    dlg.setPositiveButton("구매", null);
                    dlg.setNegativeButton("취소", null);

                    AlertDialog stockDlg= dlg.create();
                    stockDlg.show();
                    stockDlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if(dlgIngreCountEdit.getText().toString().equals("") || dlgIngreCountEdit.getText().toString().equals(0)){
                                AlertDialog.Builder purchaseDlg = new AlertDialog.Builder(StockActivity.this);
                                purchaseDlg.setMessage("구입 개수를 적어주세요.");
                                purchaseDlg.setCancelable(false);
                                purchaseDlg.setPositiveButton("확인", null);
                                purchaseDlg.show();
                            }
                            else {
                                if(allPrice <= money){
                                    AlertDialog.Builder purchaseDlg = new AlertDialog.Builder(StockActivity.this);
                                    purchaseDlg.setMessage(ingreName[index] + " " + ingreCount + "개(" + allPrice + "원)을 구매하시겠습니까?\n남은 잔액 : " + (money - allPrice) +"원");
                                    purchaseDlg.setCancelable(false);
                                    purchaseDlg.setPositiveButton("구매", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            money -= allPrice;
                                            counts[index] += ingreCount;
                                            resetValue(index);
                                            stockDlg.dismiss();
                                        }
                                    });
                                    purchaseDlg.setNegativeButton("취소", null);
                                    purchaseDlg.show();
                                }
                                else{
                                    AlertDialog.Builder purchaseDlg = new AlertDialog.Builder(StockActivity.this);
                                    purchaseDlg.setMessage("자금이 부족하여 구매할 수 없습니다.");
                                    purchaseDlg.setCancelable(false);
                                    purchaseDlg.setPositiveButton("확인", null);
                                    purchaseDlg.show();
                                }
                            }
                        }
                    });


                }
            });
        }

        stockBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lobbyIntent = new Intent(getApplicationContext(), LobbyActivity.class);
                lobbyIntent.putExtra("CountBreadTop", counts[0]);
                lobbyIntent.putExtra("CountBreadBottom", counts[1]);
                lobbyIntent.putExtra("CountSalad", counts[2]);
                lobbyIntent.putExtra("CountPickles", counts[7]);
                lobbyIntent.putExtra("CountMeat", counts[4]);
                lobbyIntent.putExtra("CountCheese", counts[6]);
                lobbyIntent.putExtra("CountTomatoes", counts[5]);
                lobbyIntent.putExtra("CountOnion", counts[3]);
                lobbyIntent.putExtra("StockMoney", money);
                setResult(RESULT_OK, lobbyIntent);
                finish();;
            }
        });


    }

    private void resetValue(int i){
        ingreCountText[i].setText(counts[i].toString());
        dlgIngreCountText.setText(counts[i] + "개");
        stockMoneyText.setText(money + "원");
    }
}
